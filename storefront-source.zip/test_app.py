from app import app


def client():
    app.config["TESTING"] = True
    return app.test_client()


def test_health():
    assert client().get("/health").status_code == 200


def test_home_serves_storefront():
    r = client().get("/")
    assert r.status_code == 200
    assert b"ShopEasy" in r.data


def test_products():
    r = client().get("/api/products")
    assert r.status_code == 200
    assert len(r.get_json()) == 10


def test_info():
    data = client().get("/api/info").get_json()
    assert "version" in data and "host" in data


def test_checkout_total_with_shipping():
    r = client().post("/api/checkout", json={"items": [{"id": 9, "qty": 2}]})
    assert r.status_code == 201
    body = r.get_json()
    assert body["subtotal"] == 1998
    assert body["shipping"] == 99
    assert body["total"] == 2097


def test_checkout_free_shipping_and_coupon():
    r = client().post("/api/checkout", json={"items": [{"id": 1, "qty": 1}], "coupon": "easy10"})
    body = r.get_json()
    assert r.status_code == 201
    assert body["discount"] == 799
    assert body["shipping"] == 0
    assert body["total"] == 7200


def test_checkout_rejects_bad_input():
    c = client()
    assert c.post("/api/checkout", json={"items": []}).status_code == 400
    assert c.post("/api/checkout", json={"items": [{"id": 999, "qty": 1}]}).status_code == 400
    assert c.post("/api/checkout", json={"items": [{"id": 1, "qty": 0}]}).status_code == 400
    assert c.post("/api/checkout", json={"items": [{"id": 1, "qty": 1}], "coupon": "NOPE"}).status_code == 400
