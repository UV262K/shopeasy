"""ShopEasy: Flask storefront. Serves the UI and a small JSON API."""
import os
import socket
import itertools
from flask import Flask, jsonify, request, send_from_directory

app = Flask(__name__, static_folder="static", static_url_path="/static")

APP_VERSION = os.environ.get("APP_VERSION", "v4")
FREE_SHIPPING_FROM = 4000
SHIPPING_FEE = 99
COUPONS = {"EASY10": 10}  # code -> percent off
_order_numbers = itertools.count(1042)

# Single source of truth for the catalogue. Prices are in rupees.
PRODUCTS = [
    {"id": 1, "name": "Halo headphones", "cat": "Audio", "price": 7999, "grade": "dusk", "kind": "headphones",
     "blurb": "Over-ear, closed back, built for long call days and louder evenings.",
     "specs": ["40 hour battery", "Active noise cancelling", "USB-C fast charge"],
     "colors": [["#ff5d8f", "#ffb86b", "Sunset"], ["#7c5cff", "#c9b8ff", "Violet"], ["#2b2550", "#6a63a8", "Ink"]]},
    {"id": 2, "name": "Pebble speaker", "cat": "Audio", "price": 3499, "grade": "orchid", "kind": "speaker",
     "blurb": "Pocket-size Bluetooth speaker with a bigger sound than it has any right to.",
     "specs": ["12 hour battery", "IP67 splash proof", "Pairs two for stereo"],
     "colors": [["#c026d3", "#38bdf8", "Orchid"], ["#ff7a59", "#ffd166", "Mango"], ["#2fd3a7", "#b7ffe9", "Mint"]]},
    {"id": 3, "name": "Tidal earbuds", "cat": "Audio", "price": 2999, "old": 3999, "grade": "lagoon", "kind": "earbuds",
     "blurb": "Light in-ear buds with a case that survives a bag full of keys.",
     "specs": ["8 hours + 24 in the case", "Low-latency game mode", "Wireless charging case"],
     "colors": [["#00c2a8", "#d4ff6a", "Lagoon"], ["#38bdf8", "#e0f4ff", "Sky"], ["#ff5d8f", "#ffd1e0", "Blush"]]},
    {"id": 4, "name": "Lumen desk lamp", "cat": "Desk", "price": 2499, "old": 3199, "grade": "ember", "kind": "lamp",
     "blurb": "A slim arm lamp with warm-to-cool light you can dial in by touch.",
     "specs": ["3 colour temperatures", "Touch dimming", "Clamp or base mount"],
     "colors": [["#ff4d2e", "#ffc83d", "Ember"], ["#f5f5f5", "#b8b8d0", "Chalk"], ["#14112b", "#5b54a0", "Night"]]},
    {"id": 5, "name": "Click75 keyboard", "cat": "Desk", "price": 5499, "grade": "orchid", "kind": "keyboard",
     "blurb": "A 75% mechanical board with hot-swap switches and a satisfying thock.",
     "specs": ["Hot-swap switches", "Bluetooth + USB-C", "PBT keycaps"],
     "colors": [["#c026d3", "#38bdf8", "Orchid"], ["#ffb86b", "#ff5d8f", "Peach"], ["#3b3a52", "#9a98c4", "Slate"]]},
    {"id": 6, "name": "Glide mouse", "cat": "Desk", "price": 1799, "grade": "dusk", "kind": "mouse",
     "blurb": "A quiet, light wireless mouse that fits a hand without a claw grip.",
     "specs": ["Silent clicks", "4000 DPI sensor", "Works on three devices"],
     "colors": [["#ff5d8f", "#ffb86b", "Sunset"], ["#38bdf8", "#c9f0ff", "Ice"], ["#2b2550", "#6a63a8", "Ink"]]},
    {"id": 7, "name": "Dock Six hub", "cat": "Desk", "price": 2199, "grade": "lagoon", "kind": "hub",
     "blurb": "Six ports in a block the size of a deck of cards. One cable to your laptop.",
     "specs": ["HDMI 4K60", "100W pass-through", "SD and microSD readers"],
     "colors": [["#00c2a8", "#d4ff6a", "Lagoon"], ["#8f8fb5", "#dcdcf2", "Steel"], ["#ff7a59", "#ffd166", "Mango"]]},
    {"id": 8, "name": "Trail backpack", "cat": "Carry", "price": 3899, "old": 4799, "grade": "citrus", "kind": "backpack",
     "blurb": "A 22 litre pack with a padded laptop sleeve and a pocket where you can find your keys.",
     "specs": ["Fits a 16 inch laptop", "Water resistant fabric", "Hidden back pocket"],
     "colors": [["#7ddc3a", "#ffe14d", "Citrus"], ["#14112b", "#5b54a0", "Night"], ["#ff5d8f", "#ffb86b", "Sunset"]]},
    {"id": 9, "name": "Flask 700 bottle", "cat": "Carry", "price": 999, "grade": "ember", "kind": "bottle",
     "blurb": "Double-wall steel that keeps drinks cold for a day and hot until lunch.",
     "specs": ["700 ml", "Leak-proof lid", "Fits most cup holders"],
     "colors": [["#ff4d2e", "#ffc83d", "Ember"], ["#00c2a8", "#d4ff6a", "Lagoon"], ["#c026d3", "#38bdf8", "Orchid"]]},
    {"id": 10, "name": "Pulse watch", "cat": "Wear", "price": 6499, "grade": "citrus", "kind": "watch",
     "blurb": "A fitness watch with a bright always-on screen and a week of battery.",
     "specs": ["7 day battery", "Heart rate and sleep", "5 ATM water resistance"],
     "colors": [["#7ddc3a", "#ffe14d", "Citrus"], ["#ff5d8f", "#ffb86b", "Sunset"], ["#2b2550", "#6a63a8", "Ink"]]},
]
BY_ID = {p["id"]: p for p in PRODUCTS}


@app.route("/")
def home():
    resp = send_from_directory(app.static_folder, "index.html")
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@app.route("/health")
def health():
    return "OK", 200


@app.route("/api/products")
def products():
    return jsonify(PRODUCTS)


@app.route("/api/info")
def info():
    # Shows which container answered, handy for demonstrating the load balancer.
    return jsonify(version=APP_VERSION, host=socket.gethostname())


@app.route("/api/checkout", methods=["POST"])
def checkout():
    data = request.get_json(silent=True) or {}
    items = data.get("items")
    if not isinstance(items, list) or not items:
        return jsonify(error="Your bag is empty."), 400

    subtotal = 0
    for item in items:
        product = BY_ID.get(item.get("id")) if isinstance(item, dict) else None
        qty = item.get("qty") if isinstance(item, dict) else None
        if product is None:
            return jsonify(error="One of the items is no longer available."), 400
        if not isinstance(qty, int) or not 1 <= qty <= 20:
            return jsonify(error="Quantity must be between 1 and 20."), 400
        subtotal += product["price"] * qty

    code = (data.get("coupon") or "").strip().upper()
    percent = COUPONS.get(code, 0)
    if code and not percent:
        return jsonify(error=f"Coupon {code} is not valid."), 400

    discount = subtotal * percent // 100
    shipping = 0 if subtotal - discount >= FREE_SHIPPING_FROM else SHIPPING_FEE
    total = subtotal - discount + shipping
    return jsonify(order=f"EZ-{next(_order_numbers)}", subtotal=subtotal,
                   discount=discount, shipping=shipping, total=total), 201


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
